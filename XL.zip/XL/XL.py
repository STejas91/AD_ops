import urllib
import urllib.request
from openpyxl import Workbook, load_workbook
import requests
from requests import get
from bs4 import BeautifulSoup
import html5lib
import wget

workbook = load_workbook(filename=r"C:\Users\ts\Documents\EIA.xlsx")
# sheets = workbook.sheetnames
sheet = workbook.active
# values = sheet["C"].value
# print(len(values))
symbl_dict = {}
url_list = []

# url_1 = "https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?n=PET&s=A013R13121&f=M"
url_2 = "https://www.eia.gov/dnav/pet"


def url_parse(url_1):
    xl_url = []
    page = urllib.request.urlopen(url_1).read()
    soup = BeautifulSoup(page, "html5lib")
    data = soup.findAll('div', attrs={'id': 'refer'})
    for div in data:
        links = div.findAll('a')
        for a in links:
            link = a['href']
            link = link.lstrip("..")
            link = url_2 + link
            xl_url.append(link)
        print(xl_url)
    for url in xl_url:
        page1 = urllib.request.urlopen(url).read()
        soup1 = BeautifulSoup(page1, "html5lib")
        data1 = soup1.findAll('div', attrs={'id': 'tlinks'})
        for div in data1:
            xls = div.findAll('a', attrs={'class': 'reg'})
            for x in xls:
                file = x['href']
                file = file.lstrip(".")
                file_url = url_2 + file
                wget.download(file_url)


for value in sheet.iter_rows(min_row=1, min_col=1, values_only=True):
    dict1 = {value[0]: value[2]}
    symbl_dict.update(dict1)
for k, v in symbl_dict.items():
    v = v.split('.')
    try:
        v = v[1]
        v = str(v)
        url_1 = "https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?n=PET&s=" + v + "&f=M"
        # print(url)
        url_parse(url_1)
    except:
        pass
