import urllib
import urllib.request
import os
from wsgiref import headers
import wget

from openpyxl import Workbook, load_workbook
import requests
from requests import get
from bs4 import BeautifulSoup
import html5lib
from urllib.request import urlopen, urlretrieve, quote
from urllib.parse import urljoin


# If there is no such folder, the script will create one automatically
OUTPUT_DIR = r'C:\Users\ts\Documents\XL'
#if not os.path.exists(folder_location): os.mkdir(folder_location)

url_2 = "https://www.eia.gov/dnav/pet"
url = "https://www.eia.gov/dnav/pet/PET_CONS_REFMG_D_SFL_VRK_MGALPD_M.htm"
page1 = urllib.request.urlopen(url).read()
soup1 = BeautifulSoup(page1, "html5lib")
data1 = soup1.findAll('div', attrs={'id': 'tlinks'})
for div in data1:
    xls = div.findAll('a', attrs={'class': 'reg'})
    for x in xls:
        file = x['href']
        file = file.lstrip(".")
        file_url = url_2 + file
        print(file_url)
        xl_file = urllib.request.urlopen(file_url).read()
        wget.download(file_url)
        xl_file = BeautifulSoup(xl_file, "html5lib")


    # xls_1 = div.findAll('class')
    # for x in xls:
    #     if x['class'] == "reg":
    #         xls = x['href']
    #         print(xls)
